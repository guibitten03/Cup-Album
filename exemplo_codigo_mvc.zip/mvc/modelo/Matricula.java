package mvc.modelo;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Matricula extends Entidade implements Serializable {

  private Date data;
  private String aluno;
  private List<Disciplina> disciplinas;

  public Matricula() {
    super();
    this.data = new Date();
    this.aluno = "";
    this.disciplinas = new ArrayList<>();
  }

  public Matricula(int id, String aluno) {
    super(id);
    this.data = new Date();
    this.aluno = aluno;
    this.disciplinas = new ArrayList<>();
  }

  public String getAluno() {
    return aluno;
  }

  public Date getData() {
    return data;
  }

  public void setAluno(String aluno) {
    this.aluno = aluno;
  }

  public void setData(Date data) {
    this.data = data;
  }

  public void addDisciplina(Disciplina disciplina) {
    this.disciplinas.add(disciplina);
  }

  public void remDisciplina(Disciplina disciplina) {
    this.disciplinas.remove(disciplina);
  }

  public void remDisciplina(int idDisciplina) {
    for (int i = 0; i < disciplinas.size(); i++) {
      if (disciplinas.get(i).getId() == idDisciplina) {
        this.disciplinas.remove(i);
        break;
      }
    }
  }

  public String toString() {
    StringBuilder str = new StringBuilder(
        String.format("ID: %d, Data: %s, Aluno: %s, Disciplinas:",
            id, new SimpleDateFormat("dd/MM/yyyy").format(data), aluno));
    for (Disciplina disciplina : disciplinas) {
      str.append("\n\t" + disciplina);
    }
    return str.toString();
  };

}