package mvc.modelo;

import java.io.Serializable;

public class Disciplina extends Entidade implements Serializable {

  private int ch;
  private String nome;

  public Disciplina() {
    super();
    this.ch = 0;
    this.nome = "";
  }

  public Disciplina(int id, int ch, String nome) {
    super(id);
    this.ch = ch;
    this.nome = nome;
  }

  public int getCH() {
    return ch;
  }

  public String getNome() {
    return nome;
  }

  public void setCH(int ch) {
    this.ch = ch;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String toString() {
    return String.format("ID: %d, CH: %d, Nome: %s", id, ch, nome);
  };

}