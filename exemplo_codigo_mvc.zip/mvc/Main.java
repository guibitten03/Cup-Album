package mvc;

import mvc.visao.MainVisao;

public class Main {

  public static void main(String[] args) {
    new MainVisao().opcoes();
  }

}
