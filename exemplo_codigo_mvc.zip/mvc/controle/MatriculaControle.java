package mvc.controle;

import mvc.controle.DisciplinaControle;
import mvc.modelo.Disciplina;
import mvc.persistencia.MatriculaPersistencia;

public class MatriculaControle extends Controle {

  private DisciplinaControle dControle;

  public MatriculaControle(DisciplinaControle dControle) {
    super(new MatriculaPersistencia());
    this.dControle = dControle;
  }

  public Disciplina buscarDisciplina(int id) {
    return (Disciplina) dControle.buscar(id);
  }

  public Disciplina buscarDisciplina(String nome) {
    return (Disciplina) dControle.buscar(nome);
  }

}
