package mvc.controle;

import mvc.persistencia.DisciplinaPersistencia;

public class DisciplinaControle extends Controle {

  public DisciplinaControle() {
    super(new DisciplinaPersistencia());
  }

}
