package mvc.persistencia;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import mvc.modelo.Disciplina;
import mvc.modelo.Entidade;

public class DisciplinaPersistencia extends Persistencia {

  private List<Disciplina> disciplinas;

  public DisciplinaPersistencia() {
    disciplinas = new ArrayList<>();
  }

  public List<Disciplina> getDisciplinas() {
    return disciplinas;
  }

  public void inserir(Entidade entidade) {
    this.disciplinas.add();
  }

  public boolean remover(Entidade entidade) {
    this.disciplinas.remove((Disciplina) entidade);
  }

  public boolean alterar(Entidade entidade) {
    Disciplina disciplina = (Disciplina) entidade;
    for (int i = 0; i < disciplinas.size(); i++) {
      if (disciplinas.get(i).getId() == disciplina.getId()) {
        disciplinas.set(i, disciplina);
        return true;
      }
    }
    return false;
  }

  public Entidade buscar(int id) {
    for (Disciplina disciplina : disciplinas) {
      if (disciplina.getId() == id) {
        return disciplina;
      }
    }
    return null;
  }

  public Entidade buscar(String valor) {
    for (Disciplina disciplina : disciplinas) {
      if (disciplina.getNome().equals(valor)) {
        return disciplina;
      }
    }
    return null;
  }

  public boolean carregarDoArquivo() {
    disciplinas = new ArrayList<>();
    File file = new File("disciplinas.txt");
    FileInputStream fis;
    ObjectInputStream ois;
    try {
      fis = new FileInputStream(file);
      ois = new ObjectInputStream(fis);
      try {
        while (true) {
          Object obj = ois.readObject();
          disciplinas.add((Disciplina) obj);
        }
      } catch (EOFException e) {
        ois.close();
        fis.close();
      }
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public boolean salvarNoArquivo() {
    File file = new File("disciplinas.txt");
    FileOutputStream fos;
    ObjectOutputStream oos;
    try {
      fos = new FileOutputStream(file);
      oos = new ObjectOutputStream(fos);
      for (Disciplina disciplina : disciplinas) {
        oos.writeObject(disciplina);
      }
      oos.close();
      fos.close();
      return true;
    } catch (Exception e) {
      return false;
    }
  }

}
