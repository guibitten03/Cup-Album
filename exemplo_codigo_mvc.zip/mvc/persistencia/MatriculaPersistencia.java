package mvc.persistencia;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import mvc.modelo.Matricula;
import mvc.modelo.Entidade;

public class MatriculaPersistencia extends Persistencia {

  private List<Matricula> matriculas;

  public MatriculaPersistencia() {
    matriculas = new ArrayList<>();
  }

  public List<Matricula> getMatriculas() {
    return matriculas;
  }

  public void inserir(Entidade entidade) {
    this.matriculas.add((Matricula) entidade);
  }

  public boolean remover(Entidade entidade) {
    return this.matriculas.remove((Matricula) entidade);
  }

  public boolean alterar(Entidade entidade) {
    Matricula matricula = (Matricula) entidade;
    for (int i = 0; i < matriculas.size(); i++) {
      if (matriculas.get(i).getId() == matricula.getId()) {
        matriculas.set(i, Matricula);
        return true;
      }
    }
    return false;
  }

  public Entidade buscar(int id) {
    for (Matricula matricula : matriculas) {
      if (matricula.getId() == id) {
        return matricula;
      }
    }
    return null;
  }

  public Entidade buscar(String valor) {
    for (Matricula matricula : matriculas) {
      if (matricula.getAluno().equals(valor)) {
        return matricula;
      }
    }
    return null;
  }

  public boolean carregarDoArquivo() {
    matriculas = new ArrayList<>();
    File file = new File("matriculas.txt");
    FileInputStream fis;
    ObjectInputStream ois;
    try {
      fis = new FileInputStream(file);
      ois = new ObjectInputStream(fis);
      try {
        while (true) {
          Object obj = ois.readObject();
          matriculas.add((Matricula) obj);
        }
      } catch (EOFException e) {
        ois.close();
        fis.close();
      }
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public boolean salvarNoArquivo() {
    File file = new File("matriculas.txt");
    FileOutputStream fos;
    ObjectOutputStream oos;
    try {
      fos = new FileOutputStream(file);
      oos = new ObjectOutputStream(fos);
      for (Matricula Matricula : matriculas) {
        oos.writeObject(Matricula);
      }
      oos.close();
      fos.close();
      return true;
    } catch (Exception e) {
      return false;
    }
  }

}
