package mvc.visao;

import java.util.Scanner;

import mvc.controle.Controle;
import mvc.controle.DisciplinaControle;
import mvc.modelo.Disciplina;

public class DisciplinaVisao extends Visao {

  public DisciplinaVisao(Controle controle, Scanner scanner) {
    super(controle, scanner);
  }

  public int menu() {
    System.out.print(
        "\n\n0 VOLTAR" +
            "\n1 INSERIR DISCIPLINA" +
            "\n2 EXCLUIR DISCIPLINA" +
            "\n3 ALTERAR DISCIPLINA" +
            "\n4 BUSCAR DISCIPLINA POR ID" +
            "\n5 BUSCAR DISCIPLINA POR NOME" +
            "\nDIGITE SUA OPCAO: ");
    return scanner.nextInt();
  }

  public void inserir() {
    Disciplina entidade = new Disciplina();
    System.out.print("\nDigite o ID: ");
    entidade.setId(scanner.nextInt());
    System.out.print("Digite a carga horária: ");
    entidade.setCH(scanner.nextInt());
    System.out.print("Digite o nome: ");
    entidade.setNome(scanner.next());
    controle.inserir(entidade);
  }

  public void excluir() {
  }

  public void alterar() {
  }

  public void buscarPorID() {
    System.out.print("\nDigite o ID da disciplina: ");
    System.out.println(controle.buscar(scanner.nextInt()));
  }

  public void buscarPorValor() {
    System.out.print("\nDigite o nome da disciplina: ");
    System.out.println(controle.buscar(scanner.next()));
  }

}
