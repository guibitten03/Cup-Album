package mvc.visao;

import java.util.Scanner;

import mvc.controle.Controle;
import mvc.controle.MatriculaControle;
import mvc.modelo.Matricula;

public class MatriculaVisao extends Visao {

  public MatriculaVisao(Controle controle, Scanner scanner) {
    super(controle, scanner);
  }

  public int menu() {
    System.out.print(
        "\n\n0 VOLTAR" +
            "\n1 INSERIR MATRICULA" +
            "\n2 EXCLUIR MATRICULA" +
            "\n3 ALTERAR MATRICULA" +
            "\n4 BUSCAR MATRICULA POR ID" +
            "\n5 BUSCAR MATRICULA POR NOME" +
            "\nDIGITE SUA OPCAO: ");
    return scanner.nextInt();
  }

  public void inserir() {
    Matricula entidade = new Matricula();
    System.out.print("\nDigite o ID: ");
    entidade.setId(scanner.nextInt());
    System.out.print("Digite o nome do aluno: ");
    entidade.setAluno(scanner.next());
    while (true) {
      System.out.print("Deseja buscar a disciplina por (1)ID ou (2)nome: ");
      if (scanner.nextInt() == 1) {
        System.out.print("\nDigite o ID da disciplina: ");
        entidade.addDisciplina(
            ((MatriculaControle) controle).buscarDisciplina(scanner.nextInt()));
      } else {
        System.out.print("Digite o nome da disciplina: ");
        entidade.addDisciplina(
            ((MatriculaControle) controle).buscarDisciplina(scanner.next()));
      }
      System.out.print("\nDeseja adicionar outra disciplina (s/n)? ");
      if (scanner.next().equals("n"))
        break;
    }
    controle.inserir(entidade);
  }

  public void excluir() {
  }

  public void alterar() {
  }

  public void buscarPorID() {
    System.out.print("\nDigite o ID da matricula: ");
    System.out.println(controle.buscar(scanner.nextInt()));
  }

  public void buscarPorValor() {
    System.out.print("\nDigite o nome da matricula: ");
    System.out.println(controle.buscar(scanner.next()));
  }

}
