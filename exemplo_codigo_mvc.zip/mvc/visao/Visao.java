package mvc.visao;

import java.util.Scanner;

import mvc.controle.Controle;

public abstract class Visao {

  protected Controle controle;
  protected Scanner scanner;

  public Visao(Controle controle, Scanner scanner) {
    this.controle = controle;
    this.scanner = scanner;
  }

  public void opcoes() {
    while (true) {
      int op = menu();
      if (op == 0)
        return;
      else if (op == 1)
        inserir();
      else if (op == 2)
        excluir();
      else if (op == 3)
        alterar();
      else if (op == 4)
        buscarPorID();
      else if (op == 5)
        buscarPorValor();
    }
  }

  public abstract int menu();

  public abstract void inserir();

  public abstract void excluir();

  public abstract void alterar();

  public abstract void buscarPorID();

  public abstract void buscarPorValor();

}
