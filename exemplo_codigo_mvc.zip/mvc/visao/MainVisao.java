package mvc.visao;

import java.util.Scanner;

import mvc.controle.DisciplinaControle;
import mvc.controle.MatriculaControle;
import mvc.modelo.Disciplina;

public class MainVisao {

  private Scanner scanner;
  private DisciplinaControle dControle;
  private MatriculaControle mControle;

  public MainVisao() {
    this.scanner = new Scanner(System.in);
    this.dControle = new DisciplinaControle();
    this.mControle = new MatriculaControle(dControle);
  }

  public int menu() {
    System.out.print(
        "\n\n0 SAIR" +
            "\n1 DISCIPLINA" +
            "\n2 MATRICULA" +
            "\nDIGITE SUA OPCAO: ");
    return scanner.nextInt();
  }

  public void opcoes() {

    if (!dControle.carregar())
      System.err.println("Não foi possível carregar as disciplinas do arquivo.");
    if (!mControle.carregar())
      System.err.println("Não foi possível carregar as matrículas do arquivo.");

    while (true) {
      int op = menu();
      if (op == 0)
        break;
      else if (op == 1)
        new DisciplinaVisao(dControle, scanner).opcoes();
      else if (op == 2)
        new MatriculaVisao(mControle, scanner).opcoes();
    }

    if (!dControle.salvar())
      System.err.println("Não foi possível salvar as disciplinas no arquivo.");
    if (!mControle.salvar())
      System.err.println("Não foi possível salvar as matrículas no arquivo.");
  }

}
